link "loader/testraster.tif", "loader/Tiled10x10Copy.tif";
